#include <stdio.h>
#include <string.h>

#if defined(__GNUC__)
__attribute__((noinline))
#endif
static int sample_transform(int value) {
    const char marker[] = "FaultScope benign static-analysis fixture";
    return value + (int)strlen(marker);
}

int main(void) {
    const char *message = "FaultScope headless export test; not malware";
    int result = sample_transform(7);
    printf("%s (%d)\n", message, result);
    return result == 0;
}
