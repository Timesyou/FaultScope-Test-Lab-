// Deliberately harmless debuggee used only to validate debugger event capture.
#include <Windows.h>

__declspec(noinline) static int calculate_value(int input) {
    volatile int result = input * 3 + 11;
    return result;
}

int main() {
    OutputDebugStringA("FaultScope benign x64dbg bridge fixture\n");
    volatile int observed = calculate_value(7);
    return observed == 32 ? 0 : 1;
}
