// Test-build copy of FaultScope's x64dbg event bridge, with a deterministic smoke-test command.
// This is built by x64dbg's own x64dbg_add_test() helper, not by an unrelated compiler project.
#include <Windows.h>
#include <algorithm>
#include <cstdint>
#include <string.h>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <mutex>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include "_plugins.h"

namespace {
struct Event {
    std::string type, timestampUtc, address, exceptionCode, module, description, exitCode;
    DWORD processId = 0, threadId = 0;
    bool firstChance = false;
    bool hasFirstChance = false;
};

constexpr size_t MAX_EVENTS = 10000;
int gPluginHandle = 0;
std::mutex gMutex;
std::vector<Event> gEvents;
std::string gTargetPath;
DWORD gProcessId = 0;
size_t gDroppedEvents = 0;

std::string jsonEscape(const std::string& value) {
    std::ostringstream out;
    for (unsigned char c : value) {
        switch (c) {
        case '\\': out << "\\\\"; break;
        case '"': out << "\\\""; break;
        case '\n': out << "\\n"; break;
        case '\r': out << "\\r"; break;
        case '\t': out << "\\t"; break;
        case '\b': out << "\\b"; break;
        case '\f': out << "\\f"; break;
        default: if (c < 0x20) out << ' '; else out << c;
        }
    }
    return out.str();
}

std::string hexValue(ULONG_PTR value) {
    std::ostringstream out;
    out << "0x" << std::hex << std::uppercase << static_cast<unsigned long long>(value);
    return out.str();
}

std::string nowUtc() {
    const std::time_t now = std::time(nullptr);
    std::tm value{};
    gmtime_s(&value, &now);
    char buffer[32]{};
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%dT%H:%M:%SZ", &value);
    return buffer;
}

void appendEvent(Event event) {
    std::lock_guard<std::mutex> lock(gMutex);
    if (event.timestampUtc.empty()) event.timestampUtc = nowUtc();
    if (!event.processId) event.processId = gProcessId;
    if (gEvents.size() >= MAX_EVENTS) { ++gDroppedEvents; return; }
    gEvents.push_back(std::move(event));
}

void resetSession(const char* filename) {
    std::lock_guard<std::mutex> lock(gMutex);
    gEvents.clear();
    gDroppedEvents = 0;
    gProcessId = 0;
    gTargetPath = filename ? filename : "";
    Event event;
    event.type = "debug-start";
    event.timestampUtc = nowUtc();
    event.description = "x64dbg debug session initialized";
    gEvents.push_back(std::move(event));
}

bool exportSession(int argc, char** argv) {
    if (argc < 2 || !argv || !argv[1] || !argv[1][0]) {
        _plugin_logputs("[FaultScope] Usage: faultscopeexport \"C:\\path\\report.json\"");
        return false;
    }
    std::vector<Event> events;
    std::string target;
    DWORD pid = 0;
    size_t dropped = 0;
    {
        std::lock_guard<std::mutex> lock(gMutex);
        events = gEvents;
        target = gTargetPath;
        pid = gProcessId;
        dropped = gDroppedEvents;
    }
    std::ofstream file(argv[1], std::ios::binary);
    if (!file) {
        _plugin_logprintf("[FaultScope] Could not open output file: %s\n", argv[1]);
        return false;
    }
#ifdef _WIN64
    const char* arch = "x64";
#else
    const char* arch = "x86";
#endif
    file << "{\n  \"schema\": \"faultscope.x64dbg.v1\",\n";
    file << "  \"metadata\": {"
         << "\"debugger\":\"x64dbg\","
         << "\"debuggerArchitecture\":\"" << arch << "\","
         << "\"targetPath\":\"" << jsonEscape(target) << "\","
         << "\"processId\":" << pid << ","
         << "\"generatedAtUtc\":\"" << nowUtc() << "\","
         << "\"droppedEvents\":" << dropped << "},\n";
    file << "  \"events\": [";
    for (size_t i = 0; i < events.size(); ++i) {
        const auto& e = events[i];
        if (i) file << ",";
        file << "\n    {\"type\":\"" << jsonEscape(e.type)
             << "\",\"timestampUtc\":\"" << jsonEscape(e.timestampUtc)
             << "\",\"processId\":" << e.processId
             << ",\"threadId\":" << e.threadId
             << ",\"address\":\"" << jsonEscape(e.address)
             << "\",\"exceptionCode\":\"" << jsonEscape(e.exceptionCode)
             << "\",\"firstChance\":";
        if (e.hasFirstChance) file << (e.firstChance ? "true" : "false"); else file << "null";
        file << ",\"module\":\"" << jsonEscape(e.module)
             << "\",\"description\":\"" << jsonEscape(e.description)
             << "\",\"exitCode\":\"" << jsonEscape(e.exitCode) << "\"}";
    }
    file << "\n  ]\n}\n";
    file.close();
    if (!file) {
        _plugin_logputs("[FaultScope] Failed while writing JSON report.");
        return false;
    }
    _plugin_logprintf("[FaultScope] Exported %u event(s) to %s; dropped=%u\n",
        static_cast<unsigned int>(events.size()), argv[1], static_cast<unsigned int>(dropped));
    return true;
}

bool faultscopeAssert(int, char**) {
    bool sawStart = false;
    bool sawProcessCreated = false;
    std::string target;
    DWORD pid = 0;
    {
        std::lock_guard<std::mutex> lock(gMutex);
        target = gTargetPath;
        pid = gProcessId;
        for (const auto& event : gEvents) {
            if (event.type == "debug-start") sawStart = true;
            if (event.type == "process-created") sawProcessCreated = true;
        }
    }
    if (!_plugin_testassert(sawStart, "expected FaultScope to capture the debug-start callback"))
        return false;
    if (!_plugin_testassert(sawProcessCreated && pid != 0, "expected a real process-created callback and PID"))
        return false;
    return _plugin_testassert(!target.empty(), "expected FaultScope to record the target path");
}

void callback(CBTYPE type, void* data) {
    if (type == CB_INITDEBUG) {
        auto info = static_cast<PLUG_CB_INITDEBUG*>(data);
        resetSession(info ? info->szFileName : nullptr);
    } else if (type == CB_ATTACH) {
        auto info = static_cast<PLUG_CB_ATTACH*>(data);
        Event e; e.type = "process-attached"; e.description = "Debugger attached to process";
        if (info) {
            e.processId = info->dwProcessId;
            std::lock_guard<std::mutex> lock(gMutex);
            gProcessId = info->dwProcessId;
        }
        appendEvent(std::move(e));
    } else if (type == CB_CREATEPROCESS) {
        auto info = static_cast<PLUG_CB_CREATEPROCESS*>(data);
        if (info && info->fdProcessInfo) {
            std::lock_guard<std::mutex> lock(gMutex);
            gProcessId = info->fdProcessInfo->dwProcessId;
        }
        Event e; e.type = "process-created"; e.description = "Debuggee process created";
        appendEvent(std::move(e));
    } else if (type == CB_CREATETHREAD) {
        auto info = static_cast<PLUG_CB_CREATETHREAD*>(data);
        Event e; e.type = "thread-created"; e.description = "Debuggee thread created";
        if (info) {
            e.threadId = info->dwThreadId;
            if (info->CreateThread) e.address = hexValue(reinterpret_cast<ULONG_PTR>(info->CreateThread->lpStartAddress));
        }
        appendEvent(std::move(e));
    } else if (type == CB_EXCEPTION) {
        auto info = static_cast<PLUG_CB_EXCEPTION*>(data);
        if (info && info->Exception) {
            Event e; e.type = "exception";
            e.exceptionCode = hexValue(info->Exception->ExceptionRecord.ExceptionCode);
            e.address = hexValue(reinterpret_cast<ULONG_PTR>(info->Exception->ExceptionRecord.ExceptionAddress));
            e.firstChance = info->Exception->dwFirstChance != FALSE;
            e.hasFirstChance = true;
            e.description = "Exception callback observed";
            appendEvent(std::move(e));
        }
    } else if (type == CB_BREAKPOINT) {
        auto info = static_cast<PLUG_CB_BREAKPOINT*>(data);
        Event e; e.type = "breakpoint-hit"; e.description = "x64dbg breakpoint callback observed";
        if (info && info->breakpoint) e.address = hexValue(info->breakpoint->addr);
        appendEvent(std::move(e));
    } else if (type == CB_LOADDLL) {
        auto info = static_cast<PLUG_CB_LOADDLL*>(data);
        Event e; e.type = "module-loaded"; e.description = "Debuggee module loaded";
        if (info && info->modname) e.module = info->modname;
        if (info && info->LoadDll) e.address = hexValue(reinterpret_cast<ULONG_PTR>(info->LoadDll->lpBaseOfDll));
        appendEvent(std::move(e));
    } else if (type == CB_UNLOADDLL) {
        auto info = static_cast<PLUG_CB_UNLOADDLL*>(data);
        Event e; e.type = "module-unloaded"; e.description = "Debuggee module unloaded";
        if (info && info->UnloadDll) e.address = hexValue(reinterpret_cast<ULONG_PTR>(info->UnloadDll->lpBaseOfDll));
        appendEvent(std::move(e));
    } else if (type == CB_STARTTRACE) {
        auto info = static_cast<PLUG_CB_STARTTRACE*>(data);
        Event e; e.type = "trace-started";
        e.description = info && info->traceFilePath ? info->traceFilePath : "Trace recording started";
        appendEvent(std::move(e));
    } else if (type == CB_STOPTRACE) {
        Event e; e.type = "trace-stopped"; e.description = "Trace recording stopped";
        appendEvent(std::move(e));
    } else if (type == CB_EXITPROCESS) {
        auto info = static_cast<PLUG_CB_EXITPROCESS*>(data);
        Event e; e.type = "process-exit"; e.description = "Debuggee process exited";
        if (info && info->ExitProcess) e.exitCode = hexValue(info->ExitProcess->dwExitCode);
        appendEvent(std::move(e));
    } else if (type == CB_STOPDEBUG) {
        Event e; e.type = "debug-stop"; e.description = "Debug session stopped";
        appendEvent(std::move(e));
    }
}
} // namespace

extern "C" __declspec(dllexport) bool pluginit(PLUG_INITSTRUCT* initStruct) {
    if (!initStruct) return false;
    initStruct->pluginVersion = 1;
    initStruct->sdkVersion = PLUG_SDKVERSION;
    strncpy_s(initStruct->pluginName, sizeof(initStruct->pluginName), X64DBG_TEST_NAME, _TRUNCATE);
    gPluginHandle = initStruct->pluginHandle;
    _plugin_registercallback(gPluginHandle, CB_INITDEBUG, callback);
    _plugin_registercallback(gPluginHandle, CB_ATTACH, callback);
    _plugin_registercallback(gPluginHandle, CB_CREATEPROCESS, callback);
    _plugin_registercallback(gPluginHandle, CB_CREATETHREAD, callback);
    _plugin_registercallback(gPluginHandle, CB_EXCEPTION, callback);
    _plugin_registercallback(gPluginHandle, CB_BREAKPOINT, callback);
    _plugin_registercallback(gPluginHandle, CB_LOADDLL, callback);
    _plugin_registercallback(gPluginHandle, CB_UNLOADDLL, callback);
    _plugin_registercallback(gPluginHandle, CB_STARTTRACE, callback);
    _plugin_registercallback(gPluginHandle, CB_STOPTRACE, callback);
    _plugin_registercallback(gPluginHandle, CB_EXITPROCESS, callback);
    _plugin_registercallback(gPluginHandle, CB_STOPDEBUG, callback);
    _plugin_registercommand(gPluginHandle, "faultscopeexport", exportSession, false);
    _plugin_registercommand(gPluginHandle, "faultscopeassert", faultscopeAssert, false);
    return true;
}

extern "C" __declspec(dllexport) void plugstop() {
    _plugin_unregistercommand(gPluginHandle, "faultscopeassert");
    _plugin_unregistercommand(gPluginHandle, "faultscopeexport");
    _plugin_unregistercallback(gPluginHandle, CB_INITDEBUG);
    _plugin_unregistercallback(gPluginHandle, CB_ATTACH);
    _plugin_unregistercallback(gPluginHandle, CB_CREATEPROCESS);
    _plugin_unregistercallback(gPluginHandle, CB_CREATETHREAD);
    _plugin_unregistercallback(gPluginHandle, CB_EXCEPTION);
    _plugin_unregistercallback(gPluginHandle, CB_BREAKPOINT);
    _plugin_unregistercallback(gPluginHandle, CB_LOADDLL);
    _plugin_unregistercallback(gPluginHandle, CB_UNLOADDLL);
    _plugin_unregistercallback(gPluginHandle, CB_STARTTRACE);
    _plugin_unregistercallback(gPluginHandle, CB_STOPTRACE);
    _plugin_unregistercallback(gPluginHandle, CB_EXITPROCESS);
    _plugin_unregistercallback(gPluginHandle, CB_STOPDEBUG);
}

extern "C" __declspec(dllexport) void plugsetup(PLUG_SETUPSTRUCT*) {}
