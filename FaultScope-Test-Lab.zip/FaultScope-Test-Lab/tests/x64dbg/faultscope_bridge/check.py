#!/usr/bin/env python3
"""Fallback assertion: validate the actual JSON written by the loaded x64dbg plugin."""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", required=True)
    parser.add_argument("--userdir", required=True)
    parser.add_argument("--runtime-dir", required=True, type=Path)
    parser.add_argument("--artifacts-dir", required=True)
    args = parser.parse_args()
    # x64dbg's test runner launches headless.exe with cwd=bin/<arch>.
    headless_dir = args.runtime_dir.parents[1]
    report_path = headless_dir / "faultscope-session.json"
    if not report_path.is_file():
        raise SystemExit(f"FAIL: plugin did not create expected report: {report_path}")
    try:
        report = json.loads(report_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit(f"FAIL: plugin report is not valid JSON: {exc}")
    if report.get("schema") != "faultscope.x64dbg.v1":
        raise SystemExit("FAIL: plugin report schema mismatch")
    metadata = report.get("metadata")
    events = report.get("events")
    if not isinstance(metadata, dict) or not isinstance(events, list):
        raise SystemExit("FAIL: report metadata/events shape is invalid")
    if not metadata.get("targetPath"):
        raise SystemExit("FAIL: target path was not captured")
    if metadata.get("droppedEvents") != 0:
        raise SystemExit("FAIL: event buffer reported dropped events")
    arch_dir = headless_dir.name.lower()
    if arch_dir not in {"x64", "x32"}:
        raise SystemExit(f"FAIL: cannot infer debugger architecture from output directory: {headless_dir}")
    expected_arch = "x64" if arch_dir == "x64" else "x86"
    if metadata.get("debuggerArchitecture") != expected_arch:
        raise SystemExit(f"FAIL: expected {expected_arch} report, got {metadata.get('debuggerArchitecture')!r}")
    if not any(isinstance(e, dict) and e.get("type") == "debug-start" for e in events):
        raise SystemExit("FAIL: no debug-start callback reached the plugin")
    if not any(isinstance(e, dict) and e.get("type") == "process-created" and e.get("processId") for e in events):
        raise SystemExit("FAIL: no real process-created event with PID was exported")
    print(f"PASS: real plugin report validated ({len(events)} event(s), {report_path})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
