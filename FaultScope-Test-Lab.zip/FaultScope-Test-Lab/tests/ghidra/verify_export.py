#!/usr/bin/env python3
"""Strict structural validation for a real Ghidra-produced FaultScope report."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    if not raw:
        raise SystemExit("FAIL: report is empty")
    try:
        report = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise SystemExit(f"FAIL: report is not valid UTF-8 JSON: {exc}")
    if report.get("schema") != "faultscope.ghidra.v1":
        raise SystemExit("FAIL: unexpected/missing schema")
    metadata = report.get("metadata")
    if not isinstance(metadata, dict):
        raise SystemExit("FAIL: metadata must be an object")
    for key in ("programName", "format", "language", "compiler", "md5", "sha256"):
        if not isinstance(metadata.get(key), str) or not metadata[key]:
            raise SystemExit(f"FAIL: metadata.{key} is missing")
    if not re.fullmatch(r"[0-9a-fA-F]{64}", metadata["sha256"]):
        raise SystemExit("FAIL: metadata.sha256 is not a 64-character hexadecimal hash")
    for key in ("functions", "imports", "strings", "references"):
        if not isinstance(report.get(key), list):
            raise SystemExit(f"FAIL: {key} must be an array")
    if len(report["functions"]) == 0:
        raise SystemExit("FAIL: no functions exported from compiled fixture")
    if len(report["strings"]) == 0:
        raise SystemExit("FAIL: no strings exported from compiled fixture")
    function = report["functions"][0]
    if not all(isinstance(function.get(k), str) for k in ("name", "entry")):
        raise SystemExit("FAIL: function entries must include name and entry strings")
    digest = hashlib.sha256(raw).hexdigest()
    print(json.dumps({
        "status": "PASS",
        "bytes": len(raw),
        "reportSha256": digest,
        "programName": metadata["programName"],
        "binarySha256": metadata["sha256"],
        "functions": len(report["functions"]),
        "imports": len(report["imports"]),
        "strings": len(report["strings"]),
        "references": len(report["references"]),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
