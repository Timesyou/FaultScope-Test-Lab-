# FaultScope Native Test Lab — source payload

This archive contains the source files, benign fixtures, and validators consumed by the GitHub Actions workflows in the repository `Timesyou/FaultScope-Test-Lab-`.

## Included

- `scripts/ExportFaultScopeReport.java` — the FaultScope Ghidra exporter. It supports both the GUI Script Manager and Ghidra headless invocation with an explicit output path.
- `tests/x64dbg/faultscope_bridge/plugin.cpp` — a test-build form of the event-capture plugin with a test-only assertion command.
- `fixtures/ghidra_sample.c` and `tests/x64dbg/faultscope_bridge/target.cpp` — harmless native fixtures compiled during CI.
- `tests/ghidra/verify_export.py` and `tests/x64dbg/faultscope_bridge/check.py` — strict validators for the actual reports emitted by the native tools.
- `docs/validation-notes.md` — validation scope and known limitations.

## What GitHub Actions runs

The repository-root workflows (not embedded in this payload archive) build Ghidra on Linux and x64dbg on Windows. The Ghidra workflow runs `analyzeHeadless` and requires a real report. The x64dbg workflow builds x64 and x86, executes the upstream test suite using TitanEngine and GleeBug, compiles the bridge through x64dbg's test CMake helper, and validates exported events from the actual plugin.

To run the native workflows, use the repository's Actions tab. To inspect the harness locally, extract this ZIP and browse the files above.

## Safety

Only supplied benign fixtures are used by the automated tests. Do not add private customer binaries, incident dumps, internal paths, or sensitive investigation material to the public repository or its Actions artifacts. These tests validate exporter integration; they do not determine whether arbitrary binaries are benign or malicious.
