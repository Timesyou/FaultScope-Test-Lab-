# Validation notes and design decisions

## Ghidra

The workflow reads `application.java.min` from the checked-out Ghidra source and installs that exact Temurin JDK version. It follows the current upstream build pattern: dependency fetch with `gradle/support/fetchDependencies.gradle`, then `./gradlew buildGhidra --parallel`. It does not hardcode a JDK version that can silently drift from Ghidra's source requirement.

The exporter accepts the first `getScriptArgs()` entry as its output path. This is required because `askFile()` is interactive and is not appropriate for `analyzeHeadless`. With no script argument, the exporter retains the GUI Save dialog; if there is no GUI and no path, it fails with an explicit message. JSON escaping covers JSON control characters and output is UTF-8.

The integration check uses Ghidra's headless analyzer against a local C fixture. It checks the generated output rather than fabricating a sample report.

## x64dbg

The build job uses the current upstream CMake/MSVC/Ninja pattern. The plugin is staged under `src/tests/faultscope_bridge` and registered in the existing `X64DBG_STANDARD_TESTS` list. This deliberately uses the upstream CMake helper, include paths, `bridge`/`dbg` targets and architecture-specific plugin suffix logic.

The source revision is resolved before the architecture matrix starts. Both build architectures and all test jobs use this single SHA, avoiding a branch moving between build and test jobs.

The test job restores the test source files so the upstream `src/tests/run.py` discovers the custom test and the matching `check.py`. The test runner itself launches the built `headless.exe` with the plugin preloaded from the test runtime folder. The custom test initializes a benign debuggee, asks the plugin to assert its initialization callback, exports JSON into the runner working directory, and uses the fallback checker to verify the report.

## Deliberate exclusions

- No untrusted executable is launched. Both fixtures are authored here and harmless.
- No attempt is made to run x64dbg on Linux/Wine or to cross-compile it as a substitute for Windows-native behavior.
- No synthetic data is accepted as proof that the native exporters run; generated artifacts are mandatory.
- No production publication, external network service, OAuth credential, or repository secret is needed.
