// FaultScope Ghidra exporter. Supports both GUI Script Manager and headless CI.
// Headless invocation: -postScript ExportFaultScopeReport.java <absolute-output.json>
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressIterator;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class ExportFaultScopeReport extends GhidraScript {
    private static final int MAX_FUNCTIONS = 10000;
    private static final int MAX_IMPORTS = 10000;
    private static final int MAX_STRINGS = 10000;
    private static final int MAX_REFERENCES = 20000;

    // JSON string escaping for every control character, not just CR/LF/tab.
    private String q(String value) {
        if (value == null) return "";
        StringBuilder out = new StringBuilder(value.length() + 16);
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '\\': out.append("\\\\"); break;
                case '"': out.append("\\\""); break;
                case '\b': out.append("\\b"); break;
                case '\f': out.append("\\f"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                    if (c < 0x20) out.append(String.format("\\u%04x", (int)c));
                    else out.append(c);
            }
        }
        return out.toString();
    }

    private File outputFile() throws Exception {
        String[] args = getScriptArgs();
        if (args != null && args.length > 0 && args[0] != null && !args[0].trim().isEmpty()) {
            return new File(args[0]).getAbsoluteFile();
        }
        if (isRunningHeadless()) {
            throw new IllegalArgumentException(
                "Headless mode requires an output path: -postScript ExportFaultScopeReport.java <output.json>");
        }
        return askFile("Save FaultScope Ghidra JSON report", "Export");
    }

    @Override
    public void run() throws Exception {
        File out = outputFile();
        if (out == null) {
            println("Export cancelled.");
            return;
        }
        File parent = out.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IllegalStateException("Could not create report directory: " + parent);
        }

        StringBuilder b = new StringBuilder(65536);
        b.append("{\n  \"schema\": \"faultscope.ghidra.v1\",\n  \"metadata\": {");
        b.append("\"programName\":\"").append(q(currentProgram.getName())).append("\",");
        b.append("\"format\":\"").append(q(currentProgram.getExecutableFormat())).append("\",");
        b.append("\"language\":\"").append(q(currentProgram.getLanguageID().toString())).append("\",");
        b.append("\"compiler\":\"").append(q(currentProgram.getCompilerSpec().getCompilerSpecID().toString())).append("\",");
        b.append("\"md5\":\"").append(q(currentProgram.getExecutableMD5())).append("\",");
        b.append("\"sha256\":\"").append(q(currentProgram.getExecutableSHA256())).append("\"},\n  \"functions\": [");

        int count = 0;
        FunctionIterator fi = currentProgram.getFunctionManager().getFunctions(true);
        while (fi.hasNext() && count < MAX_FUNCTIONS && !monitor.isCancelled()) {
            Function f = fi.next();
            if (count++ > 0) b.append(',');
            b.append("{\"name\":\"").append(q(f.getName())).append("\",\"entry\":\"")
             .append(q(f.getEntryPoint().toString())).append("\",\"size\":")
             .append(f.getBody().getNumAddresses()).append('}');
        }

        b.append("],\n  \"imports\": [");
        count = 0;
        SymbolIterator si = currentProgram.getSymbolTable().getExternalSymbols();
        while (si.hasNext() && count < MAX_IMPORTS && !monitor.isCancelled()) {
            Symbol s = si.next();
            if (count++ > 0) b.append(',');
            b.append('"').append(q(s.getName())).append('"');
        }

        b.append("],\n  \"strings\": [");
        count = 0;
        DataIterator di = currentProgram.getListing().getDefinedData(true);
        while (di.hasNext() && count < MAX_STRINGS && !monitor.isCancelled()) {
            Data d = di.next();
            if (d.getDataType().getName().toLowerCase().contains("string") && d.getValue() != null) {
                if (count++ > 0) b.append(',');
                b.append('"').append(q(d.getValue().toString())).append('"');
            }
        }

        b.append("],\n  \"references\": [");
        count = 0;
        ReferenceManager rm = currentProgram.getReferenceManager();
        fi = currentProgram.getFunctionManager().getFunctions(true);
        while (fi.hasNext() && count < MAX_REFERENCES && !monitor.isCancelled()) {
            Function f = fi.next();
            AddressIterator ai = f.getBody().getAddresses(true);
            while (ai.hasNext() && count < MAX_REFERENCES && !monitor.isCancelled()) {
                Address a = ai.next();
                ReferenceIterator ri = rm.getReferencesFrom(a);
                while (ri.hasNext() && count < MAX_REFERENCES && !monitor.isCancelled()) {
                    Reference r = ri.next();
                    if (count++ > 0) b.append(',');
                    b.append("{\"from\":\"").append(q(r.getFromAddress().toString()))
                     .append("\",\"to\":\"").append(q(r.getToAddress().toString()))
                     .append("\",\"type\":\"").append(q(r.getReferenceType().toString())).append("\"}");
                }
            }
        }
        b.append("]\n}\n");
        Files.write(out.toPath(), b.toString().getBytes(StandardCharsets.UTF_8));
        println("FaultScope report exported: " + out.getAbsolutePath());
        println("Export limits: 10000 functions, 10000 imports, 10000 strings, 20000 references.");
        if (monitor.isCancelled()) println("WARNING: export stopped after cancellation; report may be partial.");
    }
}
